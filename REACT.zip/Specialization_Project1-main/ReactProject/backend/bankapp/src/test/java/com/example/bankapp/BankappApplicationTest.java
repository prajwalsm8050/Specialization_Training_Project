package com.example.bankapp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BankappApplicationTest {

    @Test
    void test() {
        fail("Not yet implemented");
    }

}
